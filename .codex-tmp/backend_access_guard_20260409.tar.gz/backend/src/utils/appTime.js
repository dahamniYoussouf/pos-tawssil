export const APP_TIMEZONE =
  process.env.APP_TIMEZONE ||
  process.env.TZ ||
  "Africa/Algiers";

export const APP_LOCALE = process.env.APP_LOCALE || "fr-FR";

const resolveDate = (value) => {
  if (value === undefined || value === null || value === "") return null;
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const formatWithTimeZone = (value, locale, options, fallbackFactory) => {
  const date = resolveDate(value);
  if (!date) {
    if (value !== undefined && value !== null && value !== "") {
      return String(value);
    }
    return fallbackFactory(new Date());
  }

  try {
    return new Intl.DateTimeFormat(locale, {
      timeZone: APP_TIMEZONE,
      ...options
    }).format(date);
  } catch (error) {
    return fallbackFactory(date);
  }
};

export const formatDateInAppTimeZone = (value, locale = APP_LOCALE) =>
  formatWithTimeZone(
    value,
    locale,
    {
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    },
    (date) => date.toLocaleDateString(locale)
  );

export const formatTimeInAppTimeZone = (value, locale = APP_LOCALE) =>
  formatWithTimeZone(
    value,
    locale,
    {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false
    },
    (date) =>
      date.toLocaleTimeString(locale, {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
      })
  );

export const formatDateTimeInAppTimeZone = (value, locale = APP_LOCALE) =>
  formatWithTimeZone(
    value,
    locale,
    {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: false
    },
    (date) => date.toLocaleString(locale)
  );

export const getDateStampInAppTimeZone = (value = new Date()) => {
  const date = resolveDate(value);
  if (!date) return null;

  try {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: APP_TIMEZONE,
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).formatToParts(date);

    const values = {};
    for (const part of parts) {
      if (part.type !== "literal") {
        values[part.type] = part.value;
      }
    }

    if (!values.year || !values.month || !values.day) {
      return null;
    }

    return `${values.year}${values.month}${values.day}`;
  } catch (error) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}${month}${day}`;
  }
};
