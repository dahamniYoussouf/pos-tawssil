import User from '../models/User.js';
import Client from '../models/Client.js';
import Restaurant from '../models/Restaurant.js';
import Cashier from '../models/Cashier.js';
import { verifyAccessToken } from '../config/security.js';

const RESTAURANT_ACCESS_DEFAULT_ROLES = ['restaurant', 'cashier'];
const RESTAURANT_ACCESS_ATTRIBUTES = ['id', 'user_id', 'status', 'is_active'];
const RESTAURANT_ACCESS_ERRORS = {
  pending: {
    code: 'RESTAURANT_PENDING',
    message: 'Restaurant account is pending approval. Please contact an administrator.'
  },
  suspended: {
    code: 'RESTAURANT_SUSPENDED',
    message: 'Restaurant account is suspended. Please contact an administrator.'
  },
  archived: {
    code: 'RESTAURANT_ARCHIVED',
    message: 'Restaurant account is archived. Please contact an administrator.'
  }
};

const buildRestaurantAccessDeniedPayload = (restaurant = null) => {
  if (!restaurant) {
    return {
      success: false,
      message: 'Restaurant profile not found',
      code: 'RESTAURANT_NOT_FOUND'
    };
  }

  if (restaurant.is_active !== true) {
    return {
      success: false,
      message: 'Restaurant account is disabled. Please contact an administrator.',
      code: 'RESTAURANT_DISABLED',
      restaurant: {
        id: restaurant.id,
        status: restaurant.status,
        is_active: restaurant.is_active
      }
    };
  }

  const statusError = RESTAURANT_ACCESS_ERRORS[restaurant.status] || {
    code: 'RESTAURANT_NOT_APPROVED',
    message: 'Restaurant account is not approved. Please contact an administrator.'
  };

  return {
    success: false,
    message: statusError.message,
    code: statusError.code,
    restaurant: {
      id: restaurant.id,
      status: restaurant.status,
      is_active: restaurant.is_active
    }
  };
};

const resolveRestaurantAccess = async (req) => {
  const role = req.user?.role;

  if (role === 'restaurant') {
    let restaurant = null;

    if (req.user?.restaurant_id) {
      restaurant = await Restaurant.findByPk(req.user.restaurant_id, {
        attributes: RESTAURANT_ACCESS_ATTRIBUTES
      });
    }

    if (!restaurant && req.user?.id) {
      restaurant = await Restaurant.findOne({
        where: { user_id: req.user.id },
        attributes: RESTAURANT_ACCESS_ATTRIBUTES
      });
    }

    if (restaurant?.id) {
      req.user.restaurant_id = restaurant.id;
    }

    return restaurant;
  }

  if (role === 'cashier') {
    if (!req.user?.cashier_id) {
      return null;
    }

    const cashier = await Cashier.findByPk(req.user.cashier_id, {
      attributes: ['id', 'restaurant_id']
    });

    if (!cashier?.restaurant_id) {
      return null;
    }

    req.user.restaurant_id = cashier.restaurant_id;

    return Restaurant.findByPk(cashier.restaurant_id, {
      attributes: RESTAURANT_ACCESS_ATTRIBUTES
    });
  }

  return null;
};

// Protect routes - verify access token
export const protect = async (req, res, next) => {
  try {
    let token;

    // Get token from Authorization header
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({ message: 'Unauthorized - Missing token' });
    }

    // Verify access token
    let decoded;
    try {
      decoded = verifyAccessToken(token);
    } catch (error) {
      // Token expired or invalid
      if (error.name === 'TokenExpiredError') {
        return res.status(401).json({
          message: 'Token expired',
          code: 'TOKEN_EXPIRED',
          expired: true
        });
      }
      return res.status(401).json({ message: 'Invalid token' });
    }

    // Must be an access token
    if (decoded.type !== 'access') {
      return res.status(401).json({ message: 'Invalid token type' });
    }

    // Load user
    req.user = await User.findByPk(decoded.id, {
      attributes: { exclude: ['password'] }
    });

    if (!req.user) {
      return res.status(401).json({ message: 'User not found' });
    }

    if (!req.user.is_active) {
      return res.status(403).json({ message: 'Account disabled' });
    }

    // Add profile IDs from token (no DB query needed!)
    if (decoded.client_id) {
      req.user.client_id = decoded.client_id;
    }

    if (decoded.driver_id) {
      req.user.driver_id = decoded.driver_id;
    }

    if (decoded.restaurant_id) {
      req.user.restaurant_id = decoded.restaurant_id;
    }

    if (decoded.admin_id) {
      req.user.admin_id = decoded.admin_id;
    }

    // ✅ FIX: Add cashier_id from token
    if (decoded.cashier_id) {
      req.user.cashier_id = decoded.cashier_id;
    }

    next();

  } catch (error) {
    console.error('Auth middleware error:', error);
    return res.status(401).json({ message: 'Not authorized' });
  }
};

// Optional auth (uses token if provided, but doesn't require it)
export const optionalProtect = async (req, res, next) => {
  try {
    let token;

    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return next();
    }

    let decoded;
    try {
      decoded = verifyAccessToken(token);
    } catch (error) {
      if (error.name === 'TokenExpiredError') {
        return res.status(401).json({
          message: 'Token expired',
          code: 'TOKEN_EXPIRED',
          expired: true
        });
      }
      return res.status(401).json({ message: 'Invalid token' });
    }

    if (decoded.type !== 'access') {
      return res.status(401).json({ message: 'Invalid token type' });
    }

    req.user = await User.findByPk(decoded.id, {
      attributes: { exclude: ['password'] }
    });

    if (!req.user) {
      return res.status(401).json({ message: 'User not found' });
    }

    if (!req.user.is_active) {
      return res.status(403).json({ message: 'Account disabled' });
    }

    if (decoded.client_id) req.user.client_id = decoded.client_id;
    if (decoded.driver_id) req.user.driver_id = decoded.driver_id;
    if (decoded.restaurant_id) req.user.restaurant_id = decoded.restaurant_id;
    if (decoded.admin_id) req.user.admin_id = decoded.admin_id;
    if (decoded.cashier_id) req.user.cashier_id = decoded.cashier_id;

    next();
  } catch (error) {
    console.error('Optional auth middleware error:', error);
    return res.status(401).json({ message: 'Not authorized' });
  }
};

// Verify role
export const authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        message: `Role ${req.user.role} not authorized for this action`
      });
    }
    next();
  };
};

// Role-specific middlewares
export const isClient = (req, res, next) => {
  if (req.user.role !== 'client') {
    return res.status(403).json({ message: 'Access restricted to customers' });
  }
  next();
};

export const isDriver = (req, res, next) => {
  if (req.user.role !== 'driver') {
    return res.status(403).json({ message: 'Access restricted to drivers' });
  }
  next();
};

export const requireActiveClient = async (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    if (req.user.role !== 'client') {
      return res.status(403).json({
        success: false,
        message: 'Access restricted to customers'
      });
    }

    const tokenClientId = req.user.client_id;
    const client = tokenClientId
      ? await Client.findByPk(tokenClientId)
      : await Client.findOne({ where: { user_id: req.user.id } });

    if (!client) {
      return res.status(403).json({
        success: false,
        message: 'Client profile not found'
      });
    }

    // Keep req.user.client_id consistent even if token was missing/outdated.
    req.user.client_id = client.id;
    req.client = client;

    if (!client.is_active) {
      return res.status(403).json({
        success: false,
        message: 'Client account is disabled. Please contact an administrator.',
        code: 'CLIENT_DISABLED',
        client: {
          id: client.id,
          is_active: client.is_active
        }
      });
    }

    next();
  } catch (error) {
    console.error('requireActiveClient middleware error:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

export const requireApprovedRestaurantAccess = (...roles) => {
  const targetRoles = roles.length ? roles : RESTAURANT_ACCESS_DEFAULT_ROLES;

  return async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'Authentication required'
        });
      }

      if (!targetRoles.includes(req.user.role)) {
        return next();
      }

      const restaurant = await resolveRestaurantAccess(req);
      if (!restaurant) {
        return res.status(403).json(buildRestaurantAccessDeniedPayload());
      }

      req.restaurant = restaurant;

      if (restaurant.is_active !== true || restaurant.status !== 'approved') {
        return res.status(403).json(buildRestaurantAccessDeniedPayload(restaurant));
      }

      next();
    } catch (error) {
      console.error('requireApprovedRestaurantAccess middleware error:', error);
      return res.status(500).json({
        success: false,
        message: 'Server error'
      });
    }
  };
};

export const isRestaurant = (req, res, next) => {
  if (req.user.role !== 'restaurant') {
    return res.status(403).json({ message: 'Access restricted to restaurants' });
  }
  next();
};

export const isAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access restricted to administrators' });
  }
  next();
};


export const isCashier = async (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    if (req.user.role !== 'cashier') {
      return res.status(403).json({
        success: false,
        message: 'This route is only accessible to cashiers'
      });
    }

    // Verify cashier profile exists
    if (!req.user.cashier_id) {
      return res.status(403).json({
        success: false,
        message: 'Cashier profile not found'
      });
    }

    next();
  } catch (error) {
    console.error('isCashier middleware error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};
