// src/routes/cashier.routes.js
import express from "express";
import { protect, isCashier, authorize, requireApprovedRestaurantAccess } from "../middlewares/auth.js";
import { validate } from "../middlewares/validate.js";
import { cacheMiddleware, invalidateCache } from "../middlewares/cache.middleware.js";
import * as cashierCtrl from "../controllers/cashier.controller.js";
import {
  updateCashierValidator,
  cashierStatusValidator
} from "../validators/cashierValidator.js";

const router = express.Router();
const requireCashierApproval = requireApprovedRestaurantAccess('cashier');
const requireRestaurantApproval = requireApprovedRestaurantAccess('restaurant');

router.use(
  invalidateCache([
    "cache:GET:/cashier*",
    "cache:GET:/api/v1/cashiers*",
    "cache:GET:/auth/profile*",
    "cache:GET:/api/v1/auth/profile*"
  ])
);

// ===== PROTECTED ROUTES - CASHIER'S OWN PROFILE =====
router.get("/profile/me", protect, isCashier, requireCashierApproval, cacheMiddleware({ ttl: 30 }), cashierCtrl.getProfile);
router.put("/profile", protect, isCashier, requireCashierApproval, cashierCtrl.updateProfile);
router.patch("/status", protect, isCashier, requireCashierApproval, cashierStatusValidator, validate, cashierCtrl.updateStatus);
router.get("/statistics/me", protect, isCashier, requireCashierApproval, cacheMiddleware({ ttl: 30 }), cashierCtrl.getStatistics);
router.get("/dashboard/today", protect, isCashier, requireCashierApproval, cacheMiddleware({ ttl: 15 }), cashierCtrl.getDashboardToday);
router.get("/printers", protect, isCashier, requireCashierApproval, cacheMiddleware({ ttl: 300 }), cashierCtrl.getPrinters);

// ===== ADMIN/RESTAURANT ROUTES =====
router.get("/getall", protect, authorize('admin', 'restaurant'), requireRestaurantApproval, cacheMiddleware({ ttl: 60 }), cashierCtrl.getAll);
router.get("/:id", protect, authorize('admin', 'restaurant'), requireRestaurantApproval, cacheMiddleware({ ttl: 60 }), cashierCtrl.getById);
router.put(
  "/update/:id",
  protect,
  authorize('admin', 'restaurant'),
  requireRestaurantApproval,
  updateCashierValidator,
  validate,
  cashierCtrl.update
);
router.delete("/delete/:id", protect, authorize('admin', 'restaurant'), requireRestaurantApproval, cashierCtrl.remove);

export default router;
