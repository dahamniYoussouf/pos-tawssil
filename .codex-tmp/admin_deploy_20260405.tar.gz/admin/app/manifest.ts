import type { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  const manifestData: MetadataRoute.Manifest & { gcm_sender_id: string } = {
    name: 'Tawsil Admin',
    short_name: 'Tawsil Admin',
    start_url: '/',
    display: 'standalone',
    background_color: '#ffffff',
    theme_color: '#10b981',
    icons: [
      {
        src: '/icon-192.png',
        sizes: '192x192',
        type: 'image/png'
      },
      {
        src: '/icon-512.png',
        sizes: '512x512',
        type: 'image/png'
      }
    ],
    gcm_sender_id: '103953800507'
  };

  return manifestData;
}
